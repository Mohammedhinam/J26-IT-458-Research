"""Generated RGB/metadata only. Fixture authorisations never approve dental data."""
from copy import deepcopy
import json
from pathlib import Path
import stat
import zipfile

import numpy as np
from PIL import Image
import pytest

from src.vision import exploratory_bundle as eb


def draft_fixture():
    rows = []
    for i,(split,grade) in enumerate([("Training",1),("Training",4),("Validation",1),("Validation",2)],1):
        rows.append({"source_record_id":f"{split}/{i:05}", "image_path":f"Dataset/{split}/Images/{i:05}.jpg",
                     "original_split":split, "technical_candidate":True,
                     "qualified_label_approved":False,"training_eligible":False,"mgi_grade":None,
                     "participant_id":None,"analysis_split":None,"content_group_id":f"synthetic-{i}",
                     "group_source_member_count":1,"group_original_split_presence":[split],
                     "candidate_mgi_grade":grade,"cached_qa_requires_review":False,
                     "cached_qa_issues":[],"cached_original_issues":[],"draft_exclusion_reasons":[],
                     "candidate_label_status":"strict_technically_consistent_unapproved",
                     "proposed_analysis_split":split})
    return {"status":"draft_not_approved","activated":False,"training_ready":False,"mgi_schema":[0,1,2,3,4],
            "policy":{"optional_upper_partial_policy_activated":False},
            "approval":{k:False for k in ['labels_approved','split_approved','duplicate_review_complete','participant_independence_verified']},
            "sealed_boundary":{"protected_test_content_group_ids":["sealed"],"unresolved_NP015_group_ids":["possible"]},"records":rows}


def authorization(scope, **bindings):
    # Synthetic ownership fixture; no qualified approval or participant identity.
    return {"scope":scope,"status":"owner_confirmed","authorizer":"synthetic fixture",
            "date":"synthetic","evidence_reference":"generated test only",
            "acknowledgements":{k:True for k in eb.ACKS},**bindings}


@pytest.fixture
def plan(tmp_path):
    records=eb.select_candidates(draft_fixture())
    for i,row in enumerate(records):
        path=tmp_path/'sources'/row['image_path'];path.parent.mkdir(parents=True,exist_ok=True)
        Image.new('RGB',(8,4),(40+i*40,10+i*20,90)).save(path)
        row.update(source_sha256=eb.sha256(path),source_dimensions=[8,4])
    return {"source_draft_sha256":"synthetic-draft","records":records,"protected_groups":["sealed"],
            "uncertain_groups":["possible"],"cam_ids":["Validation/00003"]}


@pytest.fixture
def package(tmp_path,plan,monkeypatch):
    monkeypatch.setattr(eb,'new_ignored_output',lambda p,category:Path(p))
    auth=authorization('package_development',source_draft_sha256=plan['source_draft_sha256'],source_plan_sha256=eb.json_digest(plan),
                       code_sha256=eb.json_digest(eb.source_code_hashes()),bundle_id='bundle')
    result=eb.package_development(plan,tmp_path/'sources',tmp_path/'bundle',auth,True)
    return tmp_path/'bundle',result


def test_select_preserves_provisional_source_and_final_fields():
    draft=draft_fixture();before=deepcopy(draft)
    candidates=eb.select_candidates(draft)
    assert len(candidates)==4 and draft==before
    candidates[0]['candidate_mgi_grade']=3
    assert draft==before and all(r['participant_id'] is None for r in candidates)


@pytest.mark.parametrize('change', ['test','cross_group','protected','np015','multi','review','historical','policy','approved','bool_grade','duplicate'])
def test_invalid_or_leaking_manifest_is_rejected(change):
    draft=draft_fixture();r=draft['records'][0]
    if change=='test':r['original_split']='Test'
    elif change=='cross_group':draft['records'][2]['content_group_id']=r['content_group_id']
    elif change=='protected':r['content_group_id']='sealed'
    elif change=='np015':r['content_group_id']='possible'
    elif change=='multi':r['group_source_member_count']=2
    elif change=='review':r['cached_qa_requires_review']=True
    elif change=='historical':r['original_cached_status']='needs_review'
    elif change=='policy':draft['policy']['optional_upper_partial_policy_activated']=True
    elif change=='approved':draft['approval']['labels_approved']=True
    elif change=='bool_grade':r['candidate_mgi_grade']=True
    elif change=='duplicate':draft['records'].append(deepcopy(r))
    with pytest.raises(ValueError):eb.select_candidates(draft)


def test_held_records_are_never_selected_or_silently_cleared():
    draft=draft_fixture();draft['records'][0].update(technical_candidate=False,draft_exclusion_reasons=['NP015 unresolved'])
    assert len(eb.select_candidates(draft))==3
    assert draft['records'][0]['draft_exclusion_reasons']==['NP015 unresolved']


@pytest.mark.parametrize('name',['/absolute.jpg','../escape.jpg','Test/a.jpg','TEST/a.jpg','images\\a.jpg','a/./b.jpg','C:/a.jpg'])
def test_paths_reject_test_traversal_and_noncanonical_names(name):
    with pytest.raises(ValueError):eb.relative_path(name)


def test_path_symlink_is_rejected_without_reading_target(tmp_path):
    (tmp_path/'secret').write_text('do not read')
    (tmp_path/'link').symlink_to(tmp_path/'secret')
    with pytest.raises(ValueError,match='Symlink'):eb.safe_file(tmp_path,'link')


def test_cache_projects_only_development_hash_fields(tmp_path,monkeypatch):
    entries=[{'split':'Training','image_path':'Dataset/Training/Images/00001.jpg','sha256':'a'*64,'width':8,'height':4,'mgi_max':'DO_NOT_DECODE'},
             {'split':'Test','image_path':'DO_NOT_DECODE','sha256':'DO_NOT_DECODE','width':10,'mgi_max':'DO_NOT_DECODE'}]
    path=tmp_path/'cache.json';path.write_text(json.dumps({'result':{'manifest':entries}},indent=2)+'\n')
    original=json.loads
    def guard(value):
        assert 'DO_NOT_DECODE' not in value
        return original(value)
    monkeypatch.setattr(eb.json,'loads',guard)
    found=eb.read_hash_inventory(path)
    assert list(found)==['Dataset/Training/Images/00001.jpg'] and 'mgi_max' not in next(iter(found.values()))


def test_dry_run_hashes_sources_without_decoding_or_packaging(tmp_path,plan,monkeypatch):
    monkeypatch.setattr(Image,'open',lambda *a,**k:pytest.fail('dry-run decoded an image'))
    result=eb.dry_run(plan,tmp_path/'sources')
    assert result['source_hashes_verified']==4 and result['images_decoded']==result['images_packaged']==0
    assert result['notice']==eb.NOTICE and not result['real_packaging_authorised']


def test_corrupt_source_is_rejected(tmp_path,plan):
    (tmp_path/'sources'/plan['records'][0]['image_path']).write_bytes(b'changed')
    with pytest.raises(ValueError,match='Source hash mismatch'):eb.dry_run(plan,tmp_path/'sources')


def test_packaging_requires_separate_scope_before_image_access(tmp_path,plan,monkeypatch):
    monkeypatch.setattr(Image,'open',lambda *a,**k:pytest.fail('unauthorised image open'))
    with pytest.raises(ValueError,match='opt-in'):eb.package_development(plan,tmp_path/'sources',tmp_path/'out',None)
    with pytest.raises(ValueError,match='scope'):eb.package_development(plan,tmp_path/'sources',tmp_path/'out',authorization('implement_only'),True)
    assert not (tmp_path/'out').exists()


def test_derivative_preserves_existing_preprocessing_and_rgb():
    image=Image.fromarray(np.arange(301*203*3,dtype=np.uint8).reshape(203,301,3))
    before=np.asarray(image).copy();small=eb.resized_rgb(image)
    assert small.mode=='RGB' and max(small.size)==224
    assert np.array_equal(eb.vp.preprocess_rgb(image).normalized_chw,eb.vp.preprocess_rgb(small).normalized_chw)
    assert np.array_equal(np.asarray(image),before)


def test_synthetic_package_is_allowlisted_and_provisional(package):
    root,result=package;bundle,records=eb.validate_bundle(root)
    assert len(records)==4 and len(bundle['files'])==5 and all(r['label_status']=='provisional' for r in records)
    assert bundle['notice']==eb.NOTICE and not bundle['qualified_labels_approved']
    with zipfile.ZipFile(result['archive']) as z:
        assert set(z.namelist())==set(bundle['files'])|{'bundle_manifest.json'}
        assert not any('Test' in name or name.endswith('.txt') for name in z.namelist())


@pytest.mark.parametrize('change',['extra','corrupt','empty_test_dir'])
def test_bundle_rejects_extra_corrupted_or_test_contents(package,change):
    root,_=package
    if change=='extra':(root/'extra.jpg').write_bytes(b'bad')
    elif change=='empty_test_dir':(root/'Test').mkdir()
    else:(root/'images/Training/00001.png').write_bytes(b'bad')
    with pytest.raises(ValueError):eb.validate_bundle(root)


def test_authorised_synthetic_extraction_roundtrip(package,tmp_path):
    root,result=package;auth=authorization('run_exploratory',archive_sha256=result['archive_sha256'],bundle_manifest_sha256=result['bundle_manifest_sha256'])
    dest=eb.extract_bundle(result['archive'],tmp_path/'unpacked',auth,True)
    assert eb.validate_bundle(dest)[0]==eb.validate_bundle(root)[0]


@pytest.mark.parametrize('name,symlink',[('../escape',False),('Test/secret.jpg',False),('payload.png',True)])
def test_zip_traversal_test_and_links_blocked_before_extraction(tmp_path,name,symlink):
    archive=tmp_path/'malicious.zip'
    with zipfile.ZipFile(archive,'w') as z:
        entry=zipfile.ZipInfo(name)
        if symlink:entry.external_attr=(stat.S_IFLNK|0o777)<<16
        z.writestr(entry,b'bad')
    auth=authorization('run_exploratory',archive_sha256=eb.sha256(archive))
    with pytest.raises(ValueError):eb.extract_bundle(archive,tmp_path/'out',auth,True)
    assert not (tmp_path/'out').exists()


def test_frozen_draft_checksum_precedes_source_access(tmp_path):
    draft=tmp_path/'draft.json';draft.write_text('{}')
    with pytest.raises(ValueError,match='checksum'):eb.prepare_plan(draft,tmp_path/'missing-cache')


def test_local_output_must_be_new_and_ignored(tmp_path):
    with pytest.raises(ValueError,match='ignored'):eb.new_ignored_output(tmp_path/'outside','data')
